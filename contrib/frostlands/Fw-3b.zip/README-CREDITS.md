## Graphical assets

Freezing point background + deco; https://sourceforge.net/projects/extremetuxracer/

nevercity background assets; https://github.com/Neverball/neverball/tree/master/data

## Music

Salcon/map music; https://github.com/SuperTux/supertux/blob/master/data/music/antarctic/salcon.ogg

Nevercity & Valley in the sky music; https://github.com/Neverball/neverball/tree/master/data/bgm

Freezing point and Down you go! music; https://sourceforge.net/projects/extremetuxracer/

Through the stones, hydropower and King of fire music; https://supertuxkart.net/Main_Page

## everthing not listed here was either created by me, FrostC or was from the base game.